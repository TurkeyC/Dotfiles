# Artifact Governance

Security-first rules for generated files.

## Goals

1. Minimize artifact creation.
2. Normalize storage location and naming.
3. Prevent sensitive data leaks.
4. Ensure deterministic cleanup.

## Default Policy

- Do not generate files unless required for debugging/evidence or explicitly requested.
- Prefer in-memory workflow:
  - session without `--persistent`
  - no trace/video unless needed
- Never store real secrets in any artifact.

## Standard Artifact Root

Use one root only:

```bash
.playwright-cli/artifacts/<YYYYMMDD>/<session>/
```

Where:
- `<YYYYMMDD>` is UTC date
- `<session>` is browser session name (`default` if omitted)

## Filename Normalization

Use:

```bash
<YYYYMMDD-HHMMSS>-<session>-<purpose>.<ext>
```

Rules:
- UTC timestamp only
- lowercase words, hyphen-separated purpose
- stable extension by artifact type

Examples:
- `20260330-142000-default-home-snapshot.yaml`
- `20260330-142101-auth-login-trace.zip`
- `20260330-142250-auth-state.json`
- `20260330-142320-checkout-video.webm`

## Recommended Mapping by Type

- Snapshot: `...-snapshot.yaml`
- Storage state: `...-state.json`
- Trace: `...-trace.zip`
- Video: `...-video.webm`
- Screenshot: `...-screenshot.png`
- PDF: `...-page.pdf`

## Data Classification

Treat these as sensitive by default:
- cookies
- localStorage/sessionStorage values
- request/response headers and bodies
- page HTML/DOM snapshots containing user data
- console/network logs

## Git Hygiene

Add these patterns to `.gitignore`:

```gitignore
.playwright-cli/artifacts/
*.auth-state.json
*.state.json
*.trace
*.network
*.webm
```

## Cleanup

### End-of-task mandatory cleanup

1. Close sessions:

```bash
playwright-cli close-all
```

2. Remove temporary artifacts created for one-off debugging:

```bash
find .playwright-cli/artifacts -type f -mmin +120 -delete
```

3. Optionally remove empty directories:

```bash
find .playwright-cli/artifacts -type d -empty -delete
```

## Retention Guidance

- Keep only artifacts required for current debugging cycle.
- Default retention target: less than 7 days.
- For sensitive environments, prefer same-day deletion.
